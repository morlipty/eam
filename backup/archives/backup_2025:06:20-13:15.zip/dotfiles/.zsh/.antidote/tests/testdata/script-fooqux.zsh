fpath+=( "$ANTIDOTE_HOME/foo/qux" )
source "$ANTIDOTE_HOME/foo/qux/qux.plugin.zsh"
