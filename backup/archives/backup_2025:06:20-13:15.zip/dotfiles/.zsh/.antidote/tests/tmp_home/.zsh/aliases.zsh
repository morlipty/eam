echo "sourcing aliases.zsh..."
