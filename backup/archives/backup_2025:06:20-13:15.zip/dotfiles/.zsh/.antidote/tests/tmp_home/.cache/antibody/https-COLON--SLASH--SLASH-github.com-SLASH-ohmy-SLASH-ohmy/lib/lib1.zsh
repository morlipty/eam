echo "sourcing ohmy/lib/lib1.zsh..."
libs=($libs ohmy:lib1)
