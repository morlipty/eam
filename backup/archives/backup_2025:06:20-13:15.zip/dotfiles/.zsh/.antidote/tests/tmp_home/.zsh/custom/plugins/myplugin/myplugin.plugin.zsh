# fake foo/bar
echo "sourcing myplugin..."
plugins+=(custom:myplugin)
