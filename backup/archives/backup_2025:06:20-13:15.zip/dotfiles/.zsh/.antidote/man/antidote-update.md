---
title: antidote-update
section: 1
header: Antidote Manual
---

# NAME

**antidote update** - update bundles

# SYNOPSIS

| antidote update [-h|\--help] [-s|\--self] [-b|\--bundles]

# DESCRIPTION

**antidote-update** updates antidote and its cloned bundles.

# OPTIONS

-h, \--help
:   Show the help documentation.

-s, \--self
:   Update antidote.

-b, \--bundles
:   Update bundles.

# EXAMPLES

| antidote update
