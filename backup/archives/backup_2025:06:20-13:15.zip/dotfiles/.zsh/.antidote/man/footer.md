# BUGS

See GitHub Issues: <https://github.com/mattmc3/antidote/issues>

# AUTHORS

- Copyright (c) 2021-2024 Matt McElheny
- antidote contributors: <https://github.com/mattmc3/antidote/graphs/contributors>

# LICENSE

MIT
